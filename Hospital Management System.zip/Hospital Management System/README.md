﻿# Hospital Management System

Hospital management project craerted in python for the summer python course at uis.

## Getting Started

Instruction

```sh
python app.py
```



## Configure

```json
{
  "database": "database.db",
  "port": 5000,
  "host": "127.0.0.1"
}
```

